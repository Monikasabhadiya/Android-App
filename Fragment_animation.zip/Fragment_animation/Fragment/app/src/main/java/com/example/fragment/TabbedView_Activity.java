package com.example.fragment;

import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;

import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;

import com.example.fragment.ui.main.PagerAdapter;
import com.example.fragment.databinding.ActivityTabbedViewBinding;

public class TabbedView_Activity extends AppCompatActivity {

    private ActivityTabbedViewBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityTabbedViewBinding.inflate(getLayoutInflater());
        View view=binding.getRoot();
        setContentView(view);

        PagerAdapter adapter = new PagerAdapter(getSupportFragmentManager());
        ViewPager viewPager = binding.viewPager;
        viewPager.setAdapter(adapter);
        TabLayout tabs = binding.tabs;


        adapter.addFragment(new Fragment_One(),"Info");
        adapter.addFragment(new Fragment_Two(),"Squads");
        adapter.addFragment(new Fragment_Three(),"Overs");

        tabs.setupWithViewPager(viewPager);
        FloatingActionButton fab = binding.fab;
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }


}