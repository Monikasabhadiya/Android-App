package com.example.fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.example.fragment.ui.main.list_Adapter;


public class Fragment_One extends Fragment {
    ListView listView;
    String[] name={"Match :PRS vs SYS",
            "Series :Bash League",
            "Date :Today",
            "Time :4:40 PM",
            "Toss :Scorcher won toss",
            "Venue :Pearth Stadium",
            "Umpires :Simon Lightbody",
            "Referee :Kent Hannam"
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view=inflater.inflate(R.layout.fragment__one,container,false);
        listView=view.findViewById(R.id.list);
        Log.d("TTT", "onCreateView: Find id="+view.findViewById(R.id.list).getId());
        list_Adapter adapter =new list_Adapter(Fragment_One.this,name);
        listView.setAdapter(adapter);

        return view;
    }
}