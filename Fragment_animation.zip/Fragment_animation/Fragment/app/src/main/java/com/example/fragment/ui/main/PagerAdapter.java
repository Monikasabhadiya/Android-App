package com.example.fragment.ui.main;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * A [FragmentPagerAdapter] that returns a fragment corresponding to
 * one of the sections/tabs/pages.
 */
public class PagerAdapter extends FragmentPagerAdapter {

    List<Fragment> fragmentList=new ArrayList<>();
    List<String>titleList=new ArrayList<>();


    public PagerAdapter(FragmentManager fm) {
        super(fm);

    }

    @Override
    public Fragment getItem(int position) {
        // getItem is called to instantiate the fragment for the given page.
        // Return a PlaceholderFragment.
        return fragmentList.get(position);
    }

    @Override
    public int getCount() {
        // Show 2 total pages.
        return 3;
    }

    public void addFragment(Fragment fragment,String title) {
        fragmentList.add(fragment);
        titleList.add(title);

    }
    public CharSequence getPageTitle(int position)
    {
        return titleList.get(position);
    }
}