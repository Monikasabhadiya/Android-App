package com.example.fragment.ui.main;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.fragment.Fragment_One;
import com.example.fragment.R;

public class list_Adapter extends BaseAdapter {
    Fragment_One fragmentOne;
    String[] name;

    public list_Adapter(Fragment_One fragmentOne, String[] name) {
        this.fragmentOne = fragmentOne;
        this.name = name;
    }

    @Override
    public int getCount() {
        return name.length;
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View view1= LayoutInflater.from(fragmentOne.getContext()).inflate(R.layout.list_item,viewGroup,false);
        TextView textView=view1.findViewById(R.id.item_text);
        textView.setText(name[i]);
        return view1;
    }
}
