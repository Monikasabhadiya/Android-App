package com.example.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fragment.R;

public class Fragment_Two extends Fragment {
    RecyclerView listView;
    String nameInd [] = {"Rohit Sharma", "Shubman Gill", "Ruturaj Gaikwad",
            "Virat Kohli", "Surya Kumar", "Sanju Samson",
            "Ishan Kishan", "Hardik Pandya", "Shardal Thakur",
            "Jadeja", "Axar Patel",};
    String infoInd []={"Batsman","boller","Batsman","Batsman","Batsman","Batsman",
            "Batsman","Allrounder","Allrounder","Allrounder","boller"};

    int imgarrInd[]={R.drawable.img_2,R.drawable.img_3,R.drawable.img_4,R.drawable.img_5,R.drawable.img_6,
            R.drawable.img_7,R.drawable.img_8,R.drawable.img_9,R.drawable.img_10,R.drawable.img_11,R.drawable.img_12,
    };


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
       View view=inflater.inflate(R.layout.fragment__two,container,false);
       listView=view.findViewById(R.id.listview);
        List_adapter_one adapter = new List_adapter_one(Fragment_Two.this, nameInd, infoInd, imgarrInd);

        LinearLayoutManager manager =new LinearLayoutManager(getContext());
        manager.setOrientation(LinearLayoutManager.VERTICAL);
        listView.setLayoutManager(manager);
        listView.setAdapter(adapter);

        return view;
    }
}