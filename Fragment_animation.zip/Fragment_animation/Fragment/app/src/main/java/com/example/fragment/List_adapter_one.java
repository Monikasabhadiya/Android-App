package com.example.fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class List_adapter_one extends RecyclerView.Adapter<List_adapter_one.Listholder> {

    Fragment_Two fragmentTwo;
    String[] nameInd;
    String[] infoInd;
    int[] imgarrInd;
    public List_adapter_one(Fragment_Two fragmentTwo, String[] nameInd, String[] infoInd, int[] imgarrInd) {
        this.fragmentTwo=fragmentTwo;
        this.nameInd = nameInd;
        this.infoInd = infoInd;
        this.imgarrInd = imgarrInd;

    }

    @NonNull
    @Override
    public List_adapter_one.Listholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View view= LayoutInflater.from(fragmentTwo.getContext()).inflate(R.layout.activity_main_item,parent,false);
       Listholder holder =new Listholder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull List_adapter_one.Listholder holder, int position) {
        holder.imageView.setImageResource(imgarrInd[position]);
        holder.txt1.setText(""+nameInd[position]);
        holder.txt2.setText(""+infoInd[position]);
    }

    @Override
    public int getItemCount() {
        return nameInd.length;
    }

    public class Listholder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView txt1,txt2;

        public Listholder(@NonNull View itemView) {
            super(itemView);
            imageView=itemView.findViewById(R.id.activity_main_item_img);
            txt1=itemView.findViewById(R.id.activity_main_item_txtname);
            txt2=itemView.findViewById(R.id.activity_main_item_txtinfo);
        }
    }
}
