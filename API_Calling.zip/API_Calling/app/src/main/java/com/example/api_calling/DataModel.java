package com.example.api_calling;

public class DataModel {
    Integer id;
    String name;
    String email;
    String city;
    String lat;
    String phone;
    String cName;

    public DataModel(Integer id, String name, String email, String city, String lat, String phone, String cName) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.city = city;
        this.lat = lat;
        this.phone = phone;
        this.cName = cName;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getcName() {
        return cName;
    }

    public void setcName(String cName) {
        this.cName = cName;
    }

    @Override
    public String toString() {
        return "DataModel{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", city='" + city + '\'' +
                ", lat='" + lat + '\'' +
                ", phone='" + phone + '\'' +
                ", cName='" + cName + '\'' +
                '}';
    }
}
