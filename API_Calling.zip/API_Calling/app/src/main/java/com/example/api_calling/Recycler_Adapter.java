package com.example.api_calling;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;


public class Recycler_Adapter extends RecyclerView.Adapter<Recycler_Adapter.Holder> {
    MainActivity mainActivity;
    ArrayList<DataModel> dataList;

    public Recycler_Adapter(MainActivity mainActivity, ArrayList<DataModel> dataList) {
        this.mainActivity = mainActivity;
        this.dataList = dataList;
    }

    @NonNull
    @Override
    public Recycler_Adapter.Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view= LayoutInflater.from(mainActivity).inflate(R.layout.recycle_item,parent,false);
        Holder holder=new Holder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull Recycler_Adapter.Holder holder, int position) {
        holder.id.setText("Id : "+dataList.get(position).getId());
        holder.name.setText("Name : "+dataList.get(position).getName());
        holder.email.setText("Email : "+dataList.get(position).getEmail());
        holder.city.setText("City : "+dataList.get(position).getCity());
        holder.lat.setText("lat : "+dataList.get(position).getLat());
        holder.phone.setText("Phone : "+dataList.get(position).getPhone());
        holder.cName.setText("Company : "+dataList.get(position).getcName());

    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public class Holder extends RecyclerView.ViewHolder {
        TextView id,name,email,city,lat,phone,cName;
        public Holder(@NonNull View itemView) {
            super(itemView);

            id=itemView.findViewById(R.id.id);
            name=itemView.findViewById(R.id.name);
            email=itemView.findViewById(R.id.email);
            city=itemView.findViewById(R.id.city);
            lat=itemView.findViewById(R.id.lat);
            phone=itemView.findViewById(R.id.phone);
            cName=itemView.findViewById(R.id.cname);


        }
    }
}
