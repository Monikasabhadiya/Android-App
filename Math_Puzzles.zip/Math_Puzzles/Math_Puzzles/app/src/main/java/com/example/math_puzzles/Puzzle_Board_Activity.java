package com.example.math_puzzles;

import static com.example.math_puzzles.Data.ansArr;
import static com.example.math_puzzles.MainActivity.editor;
import static com.example.math_puzzles.MainActivity.preferences;

import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.text.BreakIterator;

public class Puzzle_Board_Activity extends AppCompatActivity implements View.OnClickListener {
    ImageView skip, hint, gameboard, delete;
    TextView txt[] = new TextView[10];
    TextView txtAns, leveldisplay, submit;
    int levelNo = 0,lastlevel;
    String temp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_puzzle_board);
        gameboard = findViewById(R.id.game_board);
        skip=findViewById(R.id.skip);
        hint=findViewById(R.id.hint);
        delete = findViewById(R.id.delete);
        txtAns = findViewById(R.id.ans_text);
        leveldisplay = findViewById(R.id.level_display);
        submit = findViewById(R.id.submit);

        for (int i = 0; i < txt.length; i++) {
            int id = getResources().getIdentifier("num" + i, "id", getPackageName());
            txt[i] = findViewById(id);
            txt[i].setOnClickListener(this);
        }
        delete.setOnClickListener(this);
        submit.setOnClickListener(this);
        if(getIntent().getExtras()!=null)
        {
            levelNo=getIntent().getIntExtra("levelNo",0); //1
        }
        lastlevel=preferences.getInt("lastlevel",0);

        leveldisplay.setText("LEVEL  " + (levelNo+1));//0+1 =1 + 1 = 2
        gameboard.setImageResource(Data.imgArr[levelNo]); // 0 1
        skip.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                MaterialAlertDialogBuilder dialogBuilder=new MaterialAlertDialogBuilder(Puzzle_Board_Activity.this);
                dialogBuilder.setTitle("Skip..!");
                dialogBuilder.setMessage("Are you sure you want to skip this level");
                dialogBuilder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if(levelNo>=lastlevel)
                        {
                            editor.putInt("lastlevel",levelNo);//1 2 3
                            editor.putString("levelStatus"+levelNo,"skip");
                            editor.commit();
                        }
                        Intent intent=new Intent(Puzzle_Board_Activity.this,Puzzle_Board_Activity.class);
                        intent.putExtra("levelNo",(levelNo+1));
                        startActivity(intent);
                        finish();
                    }
                });
                dialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

                dialogBuilder.show();
            }
        });
        hint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
    }

    @Override
    public void onClick(View v) {
        if (txt[1].getId() == v.getId()) {
            temp = txtAns.getText().toString();
            txtAns.setText("" + temp + "1");
        }
        if (txt[2].getId() == v.getId()) {
            temp = txtAns.getText().toString();
            txtAns.setText("" + temp + "2");
        }
        if (txt[3].getId() == v.getId()) {
            temp = txtAns.getText().toString();
            txtAns.setText("" + temp + "3");
        }
        if (txt[4].getId() == v.getId()) {
            temp = txtAns.getText().toString();
            txtAns.setText("" + temp + "4");
        }
        if (txt[5].getId() == v.getId()) {
            temp = txtAns.getText().toString();
            txtAns.setText("" + temp + "5");
        }
        if (txt[6].getId() == v.getId()) {
            temp = txtAns.getText().toString();
            txtAns.setText("" + temp + "6");
        }
        if (txt[7].getId() == v.getId()) {
            temp = txtAns.getText().toString();
            txtAns.setText("" + temp + "7");
        }
        if (txt[8].getId() == v.getId()) {
            temp = txtAns.getText().toString();
            txtAns.setText("" + temp + "8");
        }
        if (txt[9].getId() == v.getId()) {
            temp = txtAns.getText().toString();
            txtAns.setText("" + temp + "9");
        }
        if (txt[0].getId() == v.getId()) {
            temp = txtAns.getText().toString();
            txtAns.setText("" + temp + "0");
        }

        if (delete.getId() == v.getId()) {
            try {
                temp = temp.substring(0, txtAns.length() - 1);
                txtAns.setText("" + temp);
            } catch (StringIndexOutOfBoundsException e) {
                Toast.makeText(this, "No more degits..", Toast.LENGTH_SHORT).show();
            }
        }
        if (v.getId() == submit.getId()) {
            if (txtAns.getText().toString().equals(ansArr[levelNo]))  // 0 1
            {
               if(levelNo>=lastlevel)
               {
                   editor.putInt("lastlevel", levelNo);
                   editor.putString("levelStatus" + levelNo, "win");
                   editor.commit();
               }
                Intent intent = new Intent(Puzzle_Board_Activity.this, Win_Page_Avtivity.class);
                intent.putExtra("levelNo", levelNo); //0 1
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(this, "Wrong..!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onBackPressed() {
        Intent intent=new Intent(Puzzle_Board_Activity.this,MainActivity.class);
        intent.putExtra("levelNo",(levelNo-1));
        startActivity(intent);
        finish();

    }
}