package com.example.math_puzzles;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Win_Page_Avtivity extends AppCompatActivity {
    TextView level_complete,continue2,main_menu;
    ImageView share;
    int levelNo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_win_page_avtivity);
        level_complete=findViewById(R.id.level_complete);
        continue2=findViewById(R.id.continue2);
        main_menu=findViewById(R.id.main_menu);
        share=findViewById(R.id.share);
        levelNo=getIntent().getIntExtra("levelNo",0); //0 1
        level_complete.setText("Puzzle "+(levelNo+1)+" Completed"); // 1 2
        continue2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Win_Page_Avtivity.this,Puzzle_Board_Activity.class);
                intent.putExtra("levelNo",(levelNo+1)); //0+1 =1+1 =2
                startActivity(intent);
                finish();
            }
        });
        main_menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(Win_Page_Avtivity.this,MainActivity.class);
                intent.putExtra("levelNo",(levelNo));
                startActivity(intent);
                finish();
            }
        });
        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                share.putExtra(Intent.EXTRA_TEXT,0);
                startActivity(Intent.createChooser(share, "Share App"));
                finish();
            }
        });
    }
}