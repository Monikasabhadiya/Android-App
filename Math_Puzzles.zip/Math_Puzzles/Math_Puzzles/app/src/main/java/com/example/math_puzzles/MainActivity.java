package com.example.math_puzzles;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView continue1,puzzle;
    ImageView sharebtn,emailus;
    public static SharedPreferences preferences;
    public static SharedPreferences.Editor editor;
    int levelNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        continue1=findViewById(R.id.continue1);
        puzzle=findViewById(R.id.puzzle);
        sharebtn=findViewById(R.id.sharebtn);
        emailus=findViewById(R.id.emailus);
        preferences=getSharedPreferences("MyPref",MODE_PRIVATE);
        editor=preferences.edit();
        if(getIntent().getExtras()==null)
        {
            levelNo=preferences.getInt("lastlevel",-1); // -1
        }
        else
        {
            levelNo=getIntent().getIntExtra("levelNo",0);
        }

        continue1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this,Puzzle_Board_Activity.class);
                intent.putExtra("levelNo",(levelNo+1)); //0
                startActivity(intent);

                finish();
            }
        });
        puzzle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this,Lock_Activity.class);

                startActivity(intent);
                finish();
            }
        });
        sharebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                share.putExtra(Intent.EXTRA_TEXT,0);
                startActivity(Intent.createChooser(share, "Share App"));
            }
        });
        emailus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                share.putExtra(Intent.EXTRA_TEXT,0);
                startActivity(Intent.createChooser(share, "Share App"));
            }
        });
    }
}