package com.example.math_puzzles;

import static com.example.math_puzzles.Data.pageNo;
import static com.example.math_puzzles.MainActivity.preferences;
import static com.example.math_puzzles.R.id.lock;
import static com.example.math_puzzles.R.id.tick;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.menu.ExpandedMenuView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Lock_Activity extends AppCompatActivity {
    ImageView nextpage, prepage, lock;
    GridView gridView;
    TextView lock_item_txt;
    int levelNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lock);
        gridView = findViewById(R.id.gridview);
        prepage = findViewById(R.id.prePage);
        nextpage = findViewById(R.id.nextPage);
        levelNo = getIntent().getIntExtra("levelNo", 0);

        Lock_Adapter adapter = new Lock_Adapter(Lock_Activity.this, pageNo);
        gridView.setAdapter(adapter);

        prepage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pageNo > 1) {
                    pageNo--;
                    Lock_Adapter adapter = new Lock_Adapter(Lock_Activity.this, pageNo);
                    gridView.setAdapter(adapter);
                    Log.d("YYY", ": Page in Activity=" + pageNo);
                    if (pageNo == 1) {
                        prepage.setVisibility(View.INVISIBLE);
                    }
                    if (pageNo <= 2) {
                        nextpage.setVisibility(View.VISIBLE);
                    }
                }
            }
        });


        nextpage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pageNo < 3) {
                    pageNo++;
                    Lock_Adapter adapter = new Lock_Adapter(Lock_Activity.this, pageNo);
                    gridView.setAdapter(adapter);
                    Log.d("YYY", ": Page in Activity=" + pageNo);
                    if (pageNo > 1 && pageNo <= 2) {
                        prepage.setVisibility(View.VISIBLE);
                    }
                    if (pageNo == 3) {
                        nextpage.setVisibility(View.INVISIBLE);
                    }
                }
            }
        });

    }

    public void onBackPressed() {
        Intent intent = new Intent(Lock_Activity.this, MainActivity.class);
        // intent.putExtra("levelNo",(levelNo-1));
        pageNo = 1;
        startActivity(intent);
        finish();
    }

}