package com.example.math_puzzles;

import static com.example.math_puzzles.MainActivity.preferences;

import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class Lock_Adapter extends BaseAdapter {
    Lock_Activity lockActivity;
    String levelStatus;
    int levelNo;
    int pageNo;

    public Lock_Adapter(Lock_Activity lockActivity, int pageNo) {
        this.lockActivity = lockActivity;
        this.pageNo = pageNo;
    }

    @Override
    public int getCount() {
        return 24;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = LayoutInflater.from(lockActivity).inflate(R.layout.activity_lock_item, parent, false);
        TextView lock_item_txt = convertView.findViewById(R.id.lock_item_txt);

        ImageView lock, tick;
        RelativeLayout relative;
        relative = convertView.findViewById(R.id.relative);
        lock = convertView.findViewById(R.id.lock);
        tick = convertView.findViewById(R.id.tick);

        if (pageNo == 2) {
            position = position + 24;
        }
        if (pageNo == 3) {
            position = position + 48;
        }

        levelStatus = preferences.getString("levelStatus" + position, "pending");
        levelNo = preferences.getInt("lastlevel", -1);

        Log.d("UUU", "getView: Pos=" + position + "\tLevelStatus=" + levelStatus);
        Log.d("UUU", ": Page in Adapter=" + pageNo);


        if (position == 0 || (levelNo + 1) == (position)) {
            lock_item_txt.setVisibility(View.VISIBLE);
            lock.setVisibility(View.INVISIBLE);
            //tick.setVisibility(View.VISIBLE);
            lock_item_txt.setText("" + (position + 1));
        }
        if (levelStatus.equals("win")) {
            tick.setVisibility(View.VISIBLE);
            lock_item_txt.setVisibility(View.VISIBLE);
            lock.setVisibility(View.INVISIBLE);
            lock_item_txt.setText("" + (position + 1));

        }
        if (levelStatus.equals("skip")) {
            tick.setVisibility(View.INVISIBLE);
            lock.setVisibility(View.INVISIBLE);
            lock_item_txt.setVisibility(View.VISIBLE);
            lock_item_txt.setText("" + (position + 1));
        }
        if (position == 0 || (levelNo + 1) == (position) || levelStatus.equals("win") || levelStatus.equals("skip")) {
            int finalPosition = position;
            int finalPosition1 = position;
            relative.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.d("XXX", "getView: Second Page Position= " + finalPosition1);
                    Log.d("UUU", "true: levelstatus=" + levelStatus);
                    Intent intent = new Intent(lockActivity, Puzzle_Board_Activity.class);
                    intent.putExtra("levelNo", finalPosition);
                    lockActivity.startActivity(intent);
                    lockActivity.finish();
                }
            });
        }


        return convertView;
    }
}
