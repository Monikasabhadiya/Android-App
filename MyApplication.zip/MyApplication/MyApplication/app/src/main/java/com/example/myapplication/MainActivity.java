package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity
{
    ListView listview;
    String name[]={"Riya","Meet","Shreya","Pooja","Naitik","Vyom","Prit","Sita","Princy","Creena"};
    String data[]={"Riya","Meet","Shreya","Pooja","Naitik","Vyom","Prit","Sita","Princy","Creena"};
    int imgArr[]={R.drawable.img,R.drawable.img_1,R.drawable.img_2,R.drawable.img_3,R.drawable.img_4,R.drawable.img_5,R.drawable.img_6,R.drawable.img_7,R.drawable.img_8,R.drawable.img_9,R.drawable.img_10,R.drawable.img_11,R.drawable.img_12,R.drawable.img_13};
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listview=findViewById(R.id.listview);
        CustomAdapter adapter=new CustomAdapter(MainActivity.this,name,data,imgArr);
        listview.setAdapter(adapter);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.d("PPP", "onItemClick: Position="+position);
                Intent intent=new Intent(MainActivity.this,DetailsView_Activity.class);
                intent.putExtra("name",name);
                intent.putExtra("data",data);
                intent.putExtra("img",imgArr);
                intent.putExtra("pos",position);
                startActivity(intent);

            }
        });
    }
}