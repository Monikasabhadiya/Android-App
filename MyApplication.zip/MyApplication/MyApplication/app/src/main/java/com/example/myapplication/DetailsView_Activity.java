package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

public class DetailsView_Activity extends AppCompatActivity {

    ImageView imageView;
    TextView txt1,txt2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_view);
        imageView=findViewById(R.id.activity_details_view_imgView);
        txt1=findViewById(R.id.activity_details_view_txt1);
        txt2=findViewById(R.id.activity_details_view_txt2);

        String name[]=getIntent().getStringArrayExtra("name");
        String data[]=getIntent().getStringArrayExtra("data");
        int imgArr[]=getIntent().getIntArrayExtra("img");
        int position=getIntent().getIntExtra("pos",0);
        Log.d("PPP", "onCreate: Name in details="+name);
        txt1.setText(""+name[position]);
        imageView.setImageResource(imgArr[position]);
        txt2.setText(""+data[position]);

    }
}