package com.example.myapplication;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class CustomAdapter extends BaseAdapter {
    MainActivity mainActivity;
    String[] name;
    String[] data;
    int[] imgArr;
    public CustomAdapter(MainActivity mainActivity, String[] name, String[] data, int[] imgArr)
    {
        this.mainActivity=mainActivity;
        this.name=name;
        this.data=data;
        this.imgArr=imgArr;
    }

    @Override
    public int getCount() {
        return name.length;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView= LayoutInflater.from(mainActivity).inflate(R.layout.activity_main_item,parent,false);
        ImageView imageView=convertView.findViewById(R.id.activity_main_item_img);
        TextView textView1=convertView.findViewById(R.id.activity_main_item_txtname);
        TextView textView2=convertView.findViewById(R.id.activity_main_item_txtdata);

        imageView.setImageResource(imgArr[position]);
        textView1.setText(""+name[position]);
        textView2.setText(""+data[position]);

        return convertView;
    }
}
