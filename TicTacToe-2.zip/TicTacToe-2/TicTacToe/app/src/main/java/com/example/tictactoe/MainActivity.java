package com.example.tictactoe;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btn[] = new Button[9], btnReset;
    int counter = 0;
    TextView display;
    ArrayList list=new ArrayList();
    //List list1=new ArrayList();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        for (int i = 0; i < btn.length; i++) {
            int id = getResources().getIdentifier("btn" + i, "id", getPackageName());
            btn[i] = findViewById(id);
            Log.d("UUU", "onCreate: id of btn" + i + "=>" + id);
            btn[i].setOnClickListener(this);
        }
        btnReset=findViewById(R.id.btnReset);
        display = findViewById(R.id.display);
        btnReset.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        for (int i = 0; i < btn.length; i++) {
//            if (view.getId() == btn[i].getId()) {
//                if (counter % 2 == 0) {
//                    btn[i].setText("X");
//                    checkWin();
//                } else {
//                    btn[i].setText("O");
//                    checkWin();
//                }
//                counter++;
//                btn[i].setEnabled(false);
//            }

                if(view.getId()==btn[i].getId())
                {
                    btn[i].setText("O");
                    list.add(i);//5
                    Log.d("YYY", "onClick: Our Tick="+i);
                    counter++;
                    if(counter<=4)
                    {
                        while (true)
                        {
                            int min=0,max=9;
                            int r=new Random().nextInt(max-min)+min;//4
                            Log.d("YYY", "onClick: Random r="+r);
                            if(!list.contains(r))
                            {
                                btn[r].setText("X");
                                list.add(r);
                                Log.d("YYY", "onClick: SystemTick="+r);
                                break;
                            }


                        }
                    }
                    checkWin();

                }

            if(view.getId()==btnReset.getId()){
                btn[i].setText("");
                display.setText("");
                btn[i].setEnabled(true);
                list.clear();
                counter=0;
            }
        }
        Log.d("YYY", "onClick: List=>"+list);

    }

    private void dis() {

        for (int i = 0; i < btn.length; i++) {
            btn[i].setEnabled(false);
        }
    }

    private void checkWin() {
        if (btn[0].getText().equals("X") && btn[1].getText().equals("X") && btn[2].getText().equals("X")) {
            display.setText("x is win");
            dis();
        } else if (btn[0].getText().equals("O") && btn[1].getText().equals("O") && btn[2].getText().equals("O")) {
            display.setText("O is win");
            dis();
        } else if (btn[0].getText().equals("X") && btn[3].getText().equals("X") && btn[6].getText().equals("X")) {
            display.setText("X is win");
            dis();
        } else if (btn[0].getText().equals("O") && btn[3].getText().equals("O") && btn[6].getText().equals("O")) {
            display.setText("O is win");
            dis();
        } else if (btn[0].getText().equals("X") && btn[4].getText().equals("X") && btn[8].getText().equals("X")) {
            display.setText("X is win");
            dis();
        } else if (btn[0].getText().equals("O") && btn[4].getText().equals("O") && btn[8].getText().equals("O")) {
            display.setText("O is win");
            dis();
        } else if (btn[1].getText().equals("X") && btn[4].getText().equals("X") && btn[7].getText().equals("X")) {
            display.setText("X is win");
            dis();
        } else if (btn[1].getText().equals("O") && btn[4].getText().equals("O") && btn[7].getText().equals("O")) {
            display.setText("O is win");
            dis();
        } else if (btn[3].getText().equals("X") && btn[4].getText().equals("X") && btn[5].getText().equals("X")) {
            display.setText("X is win");
            dis();
        } else if (btn[3].getText().equals("O") && btn[4].getText().equals("O") && btn[5].getText().equals("O")) {
            display.setText("O is win");
            dis();
        } else if (btn[2].getText().equals("X") && btn[4].getText().equals("X") && btn[6].getText().equals("X")) {
            display.setText("X is win");
            dis();
        } else if (btn[2].getText().equals("O") && btn[4].getText().equals("O") && btn[6].getText().equals("O")) {
            display.setText("O is win");
            dis();
        } else if (btn[2].getText().equals("X") && btn[5].getText().equals("X") && btn[8].getText().equals("X")) {
            display.setText("X is win");
            dis();
        } else if (btn[2].getText().equals("O") && btn[5].getText().equals("O") && btn[8].getText().equals("O")) {
            display.setText("O is win");
            dis();
        } else if (btn[6].getText().equals("X") && btn[7].getText().equals("X") && btn[8].getText().equals("X")) {
            display.setText("X is win");
            dis();
        } else if (btn[6].getText().equals("O") && btn[7].getText().equals("O") && btn[8].getText().equals("O")) {
            display.setText("O is win");
            dis();
        } else if (btn[0].getText() !=("") && btn[1].getText() !=("") && btn[2].getText() !=("") && btn[3].getText() !=("") && btn[4].getText() !=("") && btn[5].getText() !=("") && btn[6].getText() !=("") && btn[7].getText() !=("") && btn[8].getText() !=("") ) {
            display.setText("Reset the game");
            dis();
        }
    }
}



