package com.example.shayariapp.Adapters;

import static com.example.shayariapp.Quotes.gradArr;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.shayariapp.Activities.Edit_Shayri_Activity;
import com.example.shayariapp.R;

public class Gradient_Adapter2 extends BaseAdapter {
    Edit_Shayri_Activity editShayriActivity;
    public Gradient_Adapter2(Edit_Shayri_Activity editShayriActivity) {
        this.editShayriActivity=editShayriActivity;
    }

    @Override
    public int getCount() {
        return gradArr.length;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView= LayoutInflater.from(editShayriActivity).inflate(R.layout.dialog_layout_item,parent,false);
        TextView textView=convertView.findViewById(R.id.dialog_layout_item_txt);
        textView.setText("Shayari App");
        textView.setBackgroundResource(gradArr[position]);
        return convertView;
    }
}
