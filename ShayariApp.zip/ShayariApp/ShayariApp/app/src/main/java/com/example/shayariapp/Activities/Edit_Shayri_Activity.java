package com.example.shayariapp.Activities;

import static com.example.shayariapp.Quotes.colorArr;
import static com.example.shayariapp.Quotes.emojiArr;
import static com.example.shayariapp.Quotes.fontArr;
import static com.example.shayariapp.Quotes.gradArr;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.shayariapp.Adapters.Colour_Adapter;
import com.example.shayariapp.Adapters.Emoji_Adapter;
import com.example.shayariapp.Adapters.Font_Adapter;
import com.example.shayariapp.Adapters.Gradient_Adapter2;
import com.example.shayariapp.Quotes;
import com.example.shayariapp.R;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

public class Edit_Shayri_Activity extends AppCompatActivity implements View.OnClickListener
{
    TextView activity_final_txt,backgroungbtn,colorbtn,sharebtn,fontbtn,emojibtn,sizebtn;
    ImageView btnexpand,btnreload;
    SeekBar seekBar;
    int progress=10;
    int pos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_shayri);
        activity_final_txt=findViewById(R.id.activity_final_txt);
        backgroungbtn=findViewById(R.id.backgroundbtn);
        colorbtn=findViewById(R.id.colorbtn);
        sharebtn=findViewById(R.id.sharebtn);
        fontbtn=findViewById(R.id.fontbtn);
        emojibtn=findViewById(R.id.emojibtn);
        sizebtn=findViewById(R.id.sizebtn);
        btnexpand=findViewById(R.id.btnexpand);
        btnreload=findViewById(R.id.btnreload);


        pos=getIntent().getIntExtra("pos",0);
        String txt=getIntent().getStringExtra("shayri");
        activity_final_txt.setText(""+txt);
        btnexpand.setOnClickListener(this);
        btnreload.setOnClickListener(this);
        backgroungbtn.setOnClickListener(this);
        colorbtn.setOnClickListener(this);
        sharebtn.setOnClickListener(this);
        fontbtn.setOnClickListener(this);
        emojibtn.setOnClickListener(this);
        sizebtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == btnexpand.getId()) {
            BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(Edit_Shayri_Activity.this);
            bottomSheetDialog.setContentView(R.layout.dialog_layout);
            GridView gridView = bottomSheetDialog.findViewById(R.id.dialog_layout_gridView);

            Gradient_Adapter2 adapter = new Gradient_Adapter2(Edit_Shayri_Activity.this);
            gridView.setAdapter(adapter);
            gridView.setNumColumns(2);
            gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    activity_final_txt.setBackgroundResource(gradArr[position]);
                    bottomSheetDialog.dismiss();
                }
            });
            bottomSheetDialog.show();
        }
        if (v.getId() == btnreload.getId()) {
            int r = new Random().nextInt(gradArr.length);
            activity_final_txt.setBackgroundResource(gradArr[r]);
        }
        if (v.getId() == backgroungbtn.getId()) {
            BottomSheetDialog dialog = new BottomSheetDialog(Edit_Shayri_Activity.this);
            dialog.setContentView(R.layout.colour_layout);
            GridView gridView = dialog.findViewById(R.id.colour_layout_gridview);
            gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    activity_final_txt.setBackgroundResource(colorArr[position]);
                    dialog.dismiss();
                }
            });
            Colour_Adapter adapter = new Colour_Adapter(Edit_Shayri_Activity.this);
            gridView.setAdapter(adapter);
            dialog.show();
        }
        if (v.getId() == colorbtn.getId()) {
            BottomSheetDialog dialog = new BottomSheetDialog(Edit_Shayri_Activity.this);
            dialog.setContentView(R.layout.colour_layout);
            GridView gridView = dialog.findViewById(R.id.colour_layout_gridview);
            gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    activity_final_txt.setTextColor(getResources().getColor(colorArr[position]));
                    dialog.dismiss();
                }
            });
            Colour_Adapter adapter = new Colour_Adapter(Edit_Shayri_Activity.this);
            gridView.setAdapter(adapter);
            dialog.show();
        }
        if (v.getId() == sharebtn.getId()) {
            Bitmap icon = getBitmapFromView(activity_final_txt);
            Intent share=new Intent(Intent.ACTION_SEND);
            share.setType("image/jpeg");
            ByteArrayOutputStream bytes=new ByteArrayOutputStream();
            icon.compress(Bitmap.CompressFormat.JPEG,100,bytes);

            SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMDD_HHmmss", Locale.getDefault());
            String currentDateandTime=sdf.format(new Date());
            File downloadedFile=new File(Quotes.file.getAbsolutePath()+"/IMG_"+currentDateandTime+".jpg");
            try {
                downloadedFile.createNewFile();
                FileOutputStream fo=new FileOutputStream(downloadedFile);
                fo.write(bytes.toByteArray());
                Toast.makeText(Edit_Shayri_Activity.this, "File Downloaded", Toast.LENGTH_SHORT).show();
            } catch (FileNotFoundException e) {
               e.printStackTrace();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            share.putExtra(Intent.EXTRA_STREAM, Uri.parse(downloadedFile.getAbsolutePath()));
            startActivity(Intent.createChooser(share,"Share Image"));
        }
        if(v.getId()==fontbtn.getId())
        {
            BottomSheetDialog dialog=new BottomSheetDialog(Edit_Shayri_Activity.this);
            dialog.setContentView(R.layout.font_layout);
            GridView gridView=dialog.findViewById(R.id.font_gridview);
            Font_Adapter adapter=new Font_Adapter(Edit_Shayri_Activity.this);
            gridView.setAdapter(adapter);
            gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Typeface typeface=Typeface.createFromAsset(getAssets(),fontArr[position]);
                    activity_final_txt.setTypeface(typeface);
                    dialog.dismiss();
                }
            });
            dialog.show();
        }
        if(v.getId()==emojibtn.getId())
        {
           BottomSheetDialog dialog=new BottomSheetDialog(Edit_Shayri_Activity.this);
            dialog.setContentView(R.layout.emojis_layout);
            ListView listView=dialog.findViewById(R.id.emojis_layout_listview);
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    activity_final_txt.setText(""+Quotes.emojiArr[position]+""+activity_final_txt+""+Quotes.emojiArr[position]);
                    dialog.dismiss();
                }
            });
            Emoji_Adapter adapter=new Emoji_Adapter(Edit_Shayri_Activity.this);
            listView.setAdapter(adapter);
            dialog.show();
        }
        if(v.getId()==sizebtn.getId())
        {
            BottomSheetDialog dialog=new BottomSheetDialog(Edit_Shayri_Activity.this);
            dialog.setContentView(R.layout.text_size_layout);
            seekBar=dialog.findViewById(R.id.seekbar);
            //seekBar.setProgress();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                seekBar.setProgress(progress);
            }
            seekBar.setMax(100);

            seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    activity_final_txt.setTextSize(2,progress);
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {

                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {
                    progress=seekBar.getProgress();
                }
            });
            dialog.show();
        }
    }

    private Bitmap getBitmapFromView(TextView activityFinalTxt) {
        Bitmap returndBitmap=Bitmap.createBitmap(activityFinalTxt.getWidth(),activityFinalTxt.getHeight(),Bitmap.Config.ARGB_8888);
        Canvas canvas=new Canvas(returndBitmap);
        Drawable bgdrawable=activityFinalTxt.getBackground();
        if(bgdrawable!=null)
        {
            bgdrawable.draw(canvas);
        }
        else {
            canvas.drawColor(Color.WHITE);
        }
        activityFinalTxt.draw(canvas);
        return returndBitmap;
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.option_menu, menu);
        return  true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if(item.getItemId()==R.id.setting)
        {
            Toast.makeText(this, "Settings Clicked", Toast.LENGTH_LONG).show();
        }
        return super.onOptionsItemSelected(item);

    }
}
