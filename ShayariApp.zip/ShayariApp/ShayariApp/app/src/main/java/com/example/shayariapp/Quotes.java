package com.example.shayariapp;

import static android.os.Environment.DIRECTORY_DOWNLOADS;

import android.os.Environment;

import java.io.File;

public class Quotes
{
    public static String[] categoriList={"Goodwishes Shayari","Friendship Shayari", "Love Shayari","Attitude Shayari",
                                          "Motivational Shayari","Life Shayari","New Year Shayari"};

    public static int imgArr[]={R.drawable.img,R.drawable.img_1,R.drawable.img_2, R.drawable.img_4,R.drawable.img_5,
            R.drawable.img_6,R.drawable.img_11};

    public static String goodwishes[]={"Your birthday only comes once a year,so make sure this is the most memorable one.Happy Birthday",
            "May your sweet smile never fade way.I wish you a very happy and sweet birthday.Happy Birthday",
            "I wish you a day filled with great fun.And a year filled with true happiness.Happy Birthday.",
            "I wish for all of your wishes to come true.Happy Birthday",
            "Be happy, for today you were born to bring blessings and inspiration to all.Happy birthday.",
            "I pray that your personal new year is filled,With an abundance of blessings.Happy Birthday To you!",
            "The Good Life Is One Inspired By Love And Guided By Knowledge....!!!",
            "I Got A Simple Rule About Everybody,If You Don't Treat Me Right, Shame On You.....!!!",
            "I Love Texting Instead Of Phone Calls,Because... It Gives Me More Time To Think What To Say.....!!!",
            "I Know I Am Awesome, So I Don't Care About Your Opinion.....!!!"};
    public static String friendship[]={"Zindagi Har Pal Kuchh Khaas Nahi Hoti,Phoolo Ki Khushboo Hamesha Paas Nahi Hoti,Milna Humari Takdeer Mein Tha Varna,Itni Pyari Dosti ittefaaq Nahi Hoti.",
    "Jindagi kisi ki mohtaj nahi hoti,Dosti sirf jujbaat nahi hoti,kuch to khayal aaya hog rub ko,verna yuhi aapki humse mulakat nahi hoti",
    "Na Rakh,Mery Doston Ko Itna Masroof,Aisa Na Ho K Meri Jaan Nikal Jay,Aur Unhain Khabr Tak Na Rahy…!!",
    "Mujhe Parwah Nahin Duniya Khafa Rahe,Bas Itni Si Dua Hai Dost Mehraban Rahe",
    "il ki gaaliyon me koi gum na ho,apni ye dosti kabhi kam na ho,bus ye dua he ki ki tum khush raho hamesha,phir chahe kal hum ho yaa naa ho",
    "Is duniya me dost kam milenge,Is duniya me gum hi gum mileneg,jaha duniya nazar fira legi,Us mod pe dost khade hum milenge ",
    "Vishwas Ki Ek Dor Hai Dosti,Betaab Dil Ki Majboori Hai Dosti,Na Maano To Kuchh Nahi Hai Dosti,Maano To Khuda Ki Bhi Kamjori Hai Dosti.",
    "Na Rakh,Mery Doston Ko Itna Masroof,Aisa Na Ho K Meri Jaan Nikal Jay,Aur Unhain Khabr Tak Na Rahy…!!",
    "kisee se roj milakar baaten karana dostee nahin,balki kisee se bichhad kar yaad rakhana dostee hai.",
    "Beshak Thoda Intajaar Mila Hamko,Par Duniya Ka Sabse Haseen Yaar Mila Hamko,Na Rahi Tamnna Ab Kisi Jannat Ki,Teri Dosti Mein Wo Pyar Mila Hamko."};
    public static String love[]={"मुझे तेरा साथ,़िंदगी भर नहीं चाहिए,बल्कि जब तक तू साथ है,तब तक जिंदगी चाहिए।",
            "सफर वही तक जहाँ तक तुम हो,नज़र वही तक जहाँ तक तुम हो,वैसे तो हज़ारों फूल खिलतें हैं गुलशन में मगर,खुशबू वही तक जहाँ तक तुम हो।",
            "जरूरी नहीं है की,इश्क बाहों के सहारे मिले,किसी को जी भर के,महसूस करना भी मोहब्बत है।",
            "प्रेम बचपन में मुफ्त मिलता है,जवानी में कमाना पड़ता है और,बुढ़ापे में मांगना पड़ता है।",
            "धड़कने आजाद है,पहरे लगा कर देख लो,प्यार छुपता ही नहीं,तुम छुपाकर देख लो।",
            "कोई चाँद से मोहब्बत करता है,कोई सूरज से मोहब्बत करता है,हम उनसे मोहब्बत करते हैं,जो हमसे मोहब्बत करते हैं।",
            "प्यार कभी सूरत से नहीं होती,इश्क तो दिल से होता है,वो तो अपने आप लगते है प्यारे,जब इज्जत उनकी दिल में होती है।",
            "सुबह का सूरज शाम का चाँद हो तुम,चेहरे की चमक होठों की मुस्कान हो तुम,पागल हैं ये दिल बस आपकी आशिक़ी में,िर क्यों न कहू की मेरी जान हो तुम।",
            "मिलना है तुझसे बिछड़ने से पहले,पाना है तुझे खोने से पहले और,जीना है तेरे साथ मरने से पहले।",
            "लफ्जों में कहाँ लिखी जाती है बेचैनियां ये मोहब्बत की,मैंने तो हर बार तुम्हे दिल की गहराइयों से पुकारा है।"};
    public static String attitude[]={"Be like a sun, keep on shining,And let the world burn.",
            "Don’t cry over money.Money never cries for you.",
            "I deserve the world,so I,m gonna give it to myself.",
            "I have a new theory in life,What other people think of me,is truly none of my business.",
            "Be yourself because an original is worth more than just a copy.",
            "Don’t Judge Yourself With Others Because,You Are Different From Them.",
            "Forget the haters because,I never count them in my life.",
            "My style is like amazone everyone says,show more show more.",
            "You can watch me, mock me. Try to block me.But you will not stop me.",
            "A girl should be like a butterfly,Pretty to see, hard to catch."};
    public static String motivational[]={"परिंदों को मंज़िल मिलेगी यक़ीनन,ये फैले हुए उनके पंख बोलते हैं,वो लोग रहते हैं खामोश अक्सर,जमाने में जिनके हुनर बोलते हैं।",
            "ज़िन्दगी बहुत हसीन है,कभी हंसाती है, तो कभी रुलाती है, लेकिन जो ज़िन्दगी की भीड़ में खुश रहता है, ़िन्दगी उसी के आगे सिर झुकाती है।",
            "अभी तो असली उड़ान बाकी है,परिंदे का इम्तिहान बाकी है,अभी अभी तो लांघा है समुंदर,अभी तो पूरा असमान बाकी है।",
            "क्यों हारता है गैर साथ नहीं है,क्या खुद का साया भी तेरे पास नहीं,ये हाथ जो तेरे साथी है,तो एक अकेला काफी है।",
            "जिंदगी एक बार मिलती है,बिल्कुल गलत है,सिर्फ मौत एक बार मिलती है,जिंदगी हर रोज मिलती है।",
            "बदल जाओ वक्त के साथ,या फिर वक्त बदलना सीखो,मजबूरियों को मत कोसो,हर हाल में चलना सीखो।",
            "जिंदगी में टेंशन ही टेंशन है,फिर भी इन लबों पर मुस्कान है,क्योंकि जीना जब हर हाल में है,तो मुस्कुराकर जीने में क्या नुकसान है।",
            "सिक्का दोनों का होता है,हेड का भी, टेल का,पर वक्त सिर्फ उसका होता है,जो पलटकर ऊपर आता है।",
            "खुद से जीतने की जिद है,मुझे खुद को ही हराना है,मैं भीड़ नहीं हूँ दुनिया की,मेरे अंदर एक ज़माना है।",
            "मालूम है कि ख़्वाब झूठे हैं,और ख्वाहिशें अधूरी हैं,पर जिंदा रहने के लिए,कुछ गलतफहमी भी जरूरी है।"};
    public static String life[]={"World is small and life is short,Spread smiles and share peace.",
            "Enjoy your own life without,comparing it with that of others.",
            "Life isn’t about finding yourself.Life is about creating yourself.",
            "My life isn’t perfect but it,does have perfect moments.",
            "Life.. not a problem to be solved.but a reality to be experienced!",
            "Life rests on the pillar of love, care & trust.Have a strong pillar to have a beautiful life.",
            "All Life is an experiment,The more experiments you make the better.",
            "Life doesn’t give you what you want.It gives you what you work for.",
            "Life is a motion from,a desire to another desire.",
            "Never build your emotional life,on the weaknesses of others."};
    public static String newyear[]={ "Life is an adventure that's full of beautiful destinations. Wishing you many wonderful memories made in 2024.",
            "Wishing you a Happy New Year, bursting with fulfilling and exciting opportunities. And remember, if opportunity doesn't knock, build a door!",
            "Happy New Year!2024 is the beginning of a new chapter. This is your year. Make it happen.",
            "Wishing you a fresh start with renewed energy and confidence throughout the New Year.",
            "Leave all the bad experiences and sorrows behind and enter the New Year with new hopes and dreams to unwind….. Wishing Happy New Year to you.",
            "Write the new chapter of your life with happiness and smiles, hope for a beautiful journey of many more miles….. Happy New Year dear.",
            "Udaas lamhon ko naa yaad rakhna…. Hansi aur Khushi ko sambhal kar rakhna…. Kisi ke liye puri duniya ho tum, yeh sach hamesha yaad rakha…. Happy New Year.",
            "Har saal hai kuch khaas…. Har saal mein hai apni mithas…. Aane wala saal bhar de aapki zindagi mein hazaron khushiyan aur pyaar ka ehsas…. Happy New Year.",
            "Ho Apko Har Shaam Mubarak,Har Chandni Ki Raat Mubarak,Ess Nav Varsh 2021 Ka,Har Ek Pal Ho Apko Mubarak",
            "Chalo Dushman Se Mulakaat Kare,Naya Saal Aaya Hai Nayi Baat Kare,Majhab K Naam Pe Kyu Danga-Fasaad ?Yahi Sawalaat Aaj Har Shaks Se Kare" };

    public static int gradArr[]={R.drawable.grad_1,R.drawable.grad_2,R.drawable.grad_3,
            R.drawable.grad_4,R.drawable.grad_5,R.drawable.grad_6,
            R.drawable.grad_7,R.drawable.grad_8,R.drawable.grad_9,
            R.drawable.grad_10,R.drawable.grad_11,R.drawable.grad_12};
    public static int colorArr[]={R.color.c1,R.color.c2,R.color.c3,R.color.c4,R.color.c5,
            R.color.c6,R.color.c7,R.color.c8,R.color.c9,R.color.c10,R.color.c11, R.color.c12,
            R.color.c13,R.color.c14,R.color.c15,R.color.c16,R.color.c17,R.color.c18};
    public  static String emojiArr[]={"\uD83D\uDC76 \uD83D\uDC67 \uD83E\uDDD2 \uD83D\uDC66 \uD83D\uDC69 \uD83E\uDDD1 \uD83D\uDC68",
    "\uD83E\uDDD4\u200D\uD83D\uDC75 \uD83E\uDDD3 \uD83D\uDC74 \uD83D\uDC72 \uD83D\uDC73\u200D\uD83D\uDC73",
    "\uD83D\uDE47 \uD83D\uDE47\u200D\uD83D\uDC81\u200D\uD83D\uDC81 \uD83D\uDC81\u200D\uD83D\uDE45\u200D\uD83D\uDE45",
    "\uD83E\uDDD1\uD83C\uDFFF\u200D\uD83D\uDE92 \uD83D\uDC68\uD83C\uDFFF\u200D\uD83D\uDE92 \uD83D\uDC69\uD83C\uDFFF\u200D\uD83E\uDDD1\uD83C\uDFFF\u200D\uD83D\uDC68\uD83C\uDFFF\u200D\uD83D\uDC69\uD83C\uDFFF\u200D\uD83D\uDE80 \uD83E\uDDD1\uD83C\uDFFF\u200D\uD83D\uDE80 \uD83D\uDC68\uD83C\uDFFF\u200D\uD83D\uDE80",
    "\uD83E\uDD71 \uD83D\uDE34 \uD83E\uDD24 \uD83D\uDE2A \uD83D\uDE35 \uD83D\uDE35\u200D\uD83D\uDCAB",
    "\uD83D\uDE3A \uD83D\uDE38 \uD83D\uDE3B \uD83D\uDE3C \uD83D\uDE3D \uD83D\uDE40 \uD83D\uDE3F \uD83D\uDE3E",
    "\uD83D\uDC36 \uD83D\uDC31 \uD83D\uDC39 \uD83D\uDC30 \uD83E\uDD8A \uD83D\uDC3B \uD83D\uDC3C \uD83D\uDC3B\u200D",
    " \uD83C\uDF39 \uD83E\uDD40 \uD83C\uDF3A \uD83C\uDF38 \uD83E\uDEBB \uD83C\uDF3C \uD83C\uDF3B",
    "\uD83C\uDF3E \uD83D\uDC90 \uD83C\uDF37 \uD83E\uDEB7 \uD83C\uDF39 \uD83E\uDD40 \uD83C\uDF3A \uD83C\uDF38 ",
    "\uD83C\uDF76  \uD83C\uDF7B \uD83E\uDD42  \uD83E\uDED7 \uD83E\uDD43  \uD83C\uDF79 \uD83E\uDDC9",
    "Without Emoji"};
    public static String fontArr[]={"CENTURY.TTF","comic.ttf","comicbd.ttf","comici.ttf","comicz.ttf",
    "Gabriola.ttf","ILLUMA-BLACK.TTF","Inkfree.ttf","MTCORSVA.TTF","seguihis.ttf","impact.ttf","javatext.ttf"};

    public static File file= Environment.getExternalStoragePublicDirectory(DIRECTORY_DOWNLOADS);

}