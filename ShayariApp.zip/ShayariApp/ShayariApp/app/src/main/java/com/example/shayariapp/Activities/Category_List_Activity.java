package com.example.shayariapp.Activities;

import static com.example.shayariapp.R.id.category_activity_list_txt;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.shayariapp.Adapters.List_Adapter;
import com.example.shayariapp.Quotes;
import com.example.shayariapp.R;

public class Category_List_Activity extends AppCompatActivity {
    ListView listView2;
    TextView textView;
    String[] shayri;
    int pos ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_list);
        listView2 = findViewById(R.id.listview2);
        textView = findViewById(category_activity_list_txt);
        pos=getIntent().getIntExtra("pos",0);


        if(pos==0)
        {
            shayri= Quotes.goodwishes;
        }
        if(pos==1)
        {
            shayri=Quotes.friendship;
        }
        if(pos==2)
        {
            shayri=Quotes.love;
        }
        if(pos==3)
        {
            shayri=Quotes.attitude;
        }
        if(pos==4)
        {
            shayri=Quotes.motivational;
        }
        if(pos==5)
        {
            shayri=Quotes.life;
        }
        if(pos==6)
        {
            shayri=Quotes.newyear;
        }
        List_Adapter adapter=new List_Adapter(Category_List_Activity.this,shayri,pos);
        listView2.setAdapter(adapter);
        listView2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent=new Intent(Category_List_Activity.this, Shayari_Details_Activity.class);
                intent.putExtra("pos",position);
                intent.putExtra("shayri",shayri);
                startActivity(intent);
            }
        });
    }
}