package com.example.shayariapp.Adapters;

import static com.example.shayariapp.Quotes.categoriList;
import static com.example.shayariapp.Quotes.imgArr;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.shayariapp.Activities.Category_Activity;
import com.example.shayariapp.R;

public class Category_Adapter extends BaseAdapter {
    Category_Activity categoryActivity;

    public Category_Adapter(Category_Activity categoryActivity) {
     this.categoryActivity=categoryActivity;

    }

    @Override
    public int getCount() {
        return categoriList.length;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView= LayoutInflater.from(categoryActivity).inflate(R.layout.category_activity_item,parent,false);
        ImageView imageView=convertView.findViewById(R.id.category_activity_item_imgView);
        TextView textView=convertView.findViewById(R.id.category_activity_item_txt);

        imageView.setImageResource(imgArr[position]);
        textView.setText(""+categoriList[position]);

        return convertView;
    }
}
