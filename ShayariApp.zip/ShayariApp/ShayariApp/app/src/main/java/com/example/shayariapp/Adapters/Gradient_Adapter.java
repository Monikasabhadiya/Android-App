package com.example.shayariapp.Adapters;

import static com.example.shayariapp.Quotes.gradArr;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.shayariapp.Activities.Edit_Shayri_Activity;
import com.example.shayariapp.Activities.Shayari_Details_Activity;
import com.example.shayariapp.R;

public class Gradient_Adapter extends BaseAdapter
{
    Shayari_Details_Activity shayariDetailsActivity;
    public Gradient_Adapter(Shayari_Details_Activity shayariDetailsActivity) {
        this.shayariDetailsActivity=shayariDetailsActivity;
    }

    @Override
    public int getCount() {
        return gradArr.length;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView= LayoutInflater.from(shayariDetailsActivity).inflate(R.layout.dialog_layout_item,parent,false);
        TextView textView=convertView.findViewById(R.id.dialog_layout_item_txt);
        textView.setText("Shayari App");
        textView.setBackgroundResource(gradArr[position]);

        return convertView;
    }
}
