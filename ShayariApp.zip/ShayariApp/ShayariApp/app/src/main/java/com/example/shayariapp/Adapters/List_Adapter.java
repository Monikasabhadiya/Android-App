package com.example.shayariapp.Adapters;

import static com.example.shayariapp.Quotes.imgArr;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.shayariapp.Activities.Category_List_Activity;
import com.example.shayariapp.R;

public class List_Adapter extends BaseAdapter {
    Category_List_Activity categoryListActivity;
    String[] shayri;
    int pos;
    public List_Adapter(Category_List_Activity categoryListActivity, String[] shayri, int pos) {
       this.categoryListActivity=categoryListActivity;
       this.shayri=shayri;
       this.pos=pos;
    }

    @Override
    public int getCount() {
        return shayri.length;
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView= LayoutInflater.from(categoryListActivity).inflate(R.layout.category_activity_item,parent,false);
        ImageView imageView=convertView.findViewById(R.id.category_activity_item_imgView);
        TextView textView=convertView.findViewById(R.id.category_activity_item_txt);
        imageView.setImageResource(imgArr[pos]);
        textView.setText(""+shayri[position]);
        return convertView;
    }
}
