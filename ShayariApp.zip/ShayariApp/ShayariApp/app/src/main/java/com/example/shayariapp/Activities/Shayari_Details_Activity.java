package com.example.shayariapp.Activities;

import static com.example.shayariapp.Quotes.gradArr;
import static com.example.shayariapp.R.id.details_textnumber;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.shayariapp.Adapters.Gradient_Adapter;
import com.example.shayariapp.Adapters.View_Pager_Adapter;
import com.example.shayariapp.Quotes;
import com.example.shayariapp.R;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.util.Random;

public class Shayari_Details_Activity extends AppCompatActivity implements View.OnClickListener
{
    ImageView btnexpand,btnreload,btncopy,btnprev,btnex1,btnnext,btnshare;
    TextView shayari_activity_txt2,details_textnumber;
    int pos,num;
    String[] shayri;
    ViewPager viewPager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shayari_details);
        btnexpand=findViewById(R.id.btnexpand);
        btnreload=findViewById(R.id.btnreload);
        btncopy=findViewById(R.id.btncopy);
        btnprev=findViewById(R.id.btnprev);
        btnex1=findViewById(R.id.btnex1);
        btnnext=findViewById(R.id.btnnext);
        btnshare=findViewById(R.id.btnshare);
        details_textnumber=findViewById(R.id.details_textnumber);
        shayari_activity_txt2=findViewById(R.id.shayari_activity_txt2);
        viewPager=findViewById(R.id.viewPager);

        pos=getIntent().getIntExtra("pos",0);
        shayri=getIntent().getStringArrayExtra("shayri");
        num=getIntent().getIntExtra("num",10);
        details_textnumber.setText((pos+1)+"/"+num);
        shayari_activity_txt2.setText(""+Quotes.emojiArr[pos]+""+shayri[pos]+""+Quotes.emojiArr[pos]);

        View_Pager_Adapter adapter=new View_Pager_Adapter(Shayari_Details_Activity.this,shayri);

        viewPager.setAdapter(adapter);
        viewPager.setCurrentItem(pos);
        viewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                shayari_activity_txt2.setText(shayri[position]);
                Log.d("PPP", "onPageSelected: position="+position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });

        btnexpand.setOnClickListener(this);
        btnreload.setOnClickListener(this);
        btncopy.setOnClickListener(this);
        btnprev.setOnClickListener(this);
        btnnext.setOnClickListener(this);
        btnex1.setOnClickListener(this);
        btnshare.setOnClickListener(this);
    }
    @Override
    public void onClick(View v) {

        if(v.getId()==btnex1.getId())
        {
            Intent intent=new Intent(Shayari_Details_Activity.this, Edit_Shayri_Activity.class);
            intent.putExtra("shayri",shayari_activity_txt2.getText().toString());
            startActivity(intent);
            fileList();
        }
        if(v.getId()==btnnext.getId())
        {

            if(pos<shayri.length-1)//9<9
            {
                pos++;//9
                shayari_activity_txt2.setText(""+Quotes.emojiArr[pos]+""+shayri[pos]+""+Quotes.emojiArr[pos]);
                details_textnumber.setText((pos+1)+"/"+num);
            }
        }
        if(v.getId()==btncopy.getId())
        {
            ClipboardManager cm = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setText(shayari_activity_txt2.getText());
            Toast.makeText(Shayari_Details_Activity.this, "Copied to clipboard", Toast.LENGTH_SHORT).show();
        }
        if(v.getId()==btnexpand.getId())
        {
            BottomSheetDialog bottomSheetDialog=new BottomSheetDialog(Shayari_Details_Activity.this);
            bottomSheetDialog.setContentView(R.layout.dialog_layout);
            GridView gridView=bottomSheetDialog.findViewById(R.id.dialog_layout_gridView);

            Gradient_Adapter adapter=new Gradient_Adapter(Shayari_Details_Activity.this);
            gridView.setAdapter(adapter);
            gridView.setNumColumns(2);
            gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    shayari_activity_txt2.setBackgroundResource(gradArr[position]);
                    bottomSheetDialog.dismiss();
                }
            });
            bottomSheetDialog.show();
        }
        if(v.getId()==btnreload.getId())
        {
            int r=new Random().nextInt(gradArr.length);
            shayari_activity_txt2.setBackgroundResource(gradArr[r]);
        }
        if(v.getId()==btnprev.getId())
        {
            if(pos>0)
            {
                pos--;
                shayari_activity_txt2.setText(""+Quotes.emojiArr[pos]+""+shayri[pos]+""+Quotes.emojiArr[pos]);
                details_textnumber.setText((pos+1)+"/"+num);
            }
        }
        if(v.getId()==btnshare.getId())
        {
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("text/plain");
            share.putExtra(Intent.EXTRA_TEXT, shayri[pos]);
            startActivity(Intent.createChooser(share, "Share Text"));
        }
    }
}