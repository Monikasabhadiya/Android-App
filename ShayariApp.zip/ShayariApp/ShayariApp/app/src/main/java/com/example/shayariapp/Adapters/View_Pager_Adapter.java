package com.example.shayariapp.Adapters;

import static android.os.Build.VERSION_CODES.R;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import com.example.shayariapp.Activities.Shayari_Details_Activity;
import com.example.shayariapp.R;

public class View_Pager_Adapter extends PagerAdapter
{
    Shayari_Details_Activity shayariDetailsActivity;
    String[] shayri;

    public View_Pager_Adapter(Shayari_Details_Activity shayariDetailsActivity, String[] shayri) {
        this.shayariDetailsActivity = shayariDetailsActivity;
        this.shayri = shayri;
    }

    @Override
    public int getCount() {
        return shayri.length;
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view==object;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        View view=LayoutInflater.from(shayariDetailsActivity).inflate(com.example.shayariapp.R.layout.peger_item,container,false);
        container.addView(view);

        Log.d("PPP", "onPageSelected: position in Adapter="+position);
        return container;

    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((View) object);
    }
}
