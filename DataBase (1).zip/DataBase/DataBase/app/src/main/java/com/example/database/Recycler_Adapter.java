package com.example.database;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;

public class Recycler_Adapter extends RecyclerView.Adapter<Recycler_Adapter.Holder>
{
    List_Activity listActivity;
    ArrayList<DataModel> dataList;
    MyDataBase db;
    public Recycler_Adapter(List_Activity listActivity, ArrayList<DataModel> dataList, MyDataBase db) {
        this.listActivity=listActivity;
        this.dataList=dataList;
        this.db=db;
    }
    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(listActivity).inflate(R.layout.list_item,parent,false);
        Holder holder=new Holder(view);
        return holder;
    }
    @Override
    public void onBindViewHolder(@NonNull Recycler_Adapter.Holder holder, int position) {
        holder.txtName.setText(""+dataList.get(position).getName());
        holder.txtNum.setText(""+dataList.get(position).getNumber());
        //loadImageFromStorage(imgList.get(position),holder.imageView);
        Glide.with(holder.itemView).load(dataList.get(position).getImgUrl()).into(holder.imageView);
        holder.optionMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PopupMenu popupMenu=new PopupMenu(listActivity,holder.optionMenu);
                popupMenu.getMenuInflater().inflate(R.menu.popup_menu,popupMenu.getMenu());
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) 
                    {
                        if(menuItem.getItemId()==R.id.update)
                        {
                            db.updatedata(dataList.get(position).getId(),dataList.get(position).getName(),dataList.get(position).getNumber(),dataList.get(position).getImgUrl());
                            Intent intent=new Intent(listActivity,MainActivity.class);
                            intent.putExtra("id",dataList.get(position).getId());
                            intent.putExtra("name",dataList.get(position).getName());
                            intent.putExtra("number",dataList.get(position).getNumber());
                            intent.putExtra("imageurl",dataList.get(position).getImgUrl());
                            listActivity.startActivity(intent);
                            Toast.makeText(listActivity, "Update Clicked", Toast.LENGTH_SHORT).show();
                        }
                        if(menuItem.getItemId()==R.id.delete)
                        {
                            Log.d("BBB", "onMenuItemClick: Data="+dataList.get(position).getId());
                            db.deleteData(dataList.get(position).getId());
                            dataList.remove(position);
                            notifyDataSetChanged();
                            Toast.makeText(listActivity, "Item Deleted", Toast.LENGTH_SHORT).show();
                        }
                        return true;
                    }
                });
                popupMenu.show();
            }
        });
    }
    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public class Holder extends RecyclerView.ViewHolder {
        TextView txtName,txtNum;
        ImageView imageView;
        ImageView optionMenu;
        public Holder(@NonNull View itemView) {
            super(itemView);
            txtName=itemView.findViewById(R.id.name);
            txtNum=itemView.findViewById(R.id.number);
            imageView=itemView.findViewById(R.id.item_Img);
            optionMenu=itemView.findViewById(R.id.optionMenu);
        }
    }
//    private void loadImageFromStorage(String path, ImageView imageView)
//    {
//        try {
//            File f=new File(path);
//            Log.d("AAA", "loadImageFromStorage: ImgPath="+path);
//            Bitmap b = BitmapFactory.decodeStream(new FileInputStream(f));
//            // ImageView img=(ImageView)findViewById(R.id.imgPicker);
//            imageView.setImageBitmap(b);
//        }
//        catch (FileNotFoundException e)
//        {
//            e.printStackTrace();
//        }
//    }
}
